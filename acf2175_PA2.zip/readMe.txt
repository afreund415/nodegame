Andreas Carlos Freund
Acf2175
CSEE-4119 Computer Networks
Programming Assignment #2


Highlights: 



Installing the project:




Running the project: 
1. SRNode: 
2. DVNode: 
3. CNNode: 

Commandline options SRNode: 
1. Send <message>, where message is any list of characters that the program can split into packets
2. sendtest <# of characters> this allows the user to run an emulation test where they send a message (with ACK failures turned off)  


Commandline options DVNode: 

Commandline options CNNode: 

